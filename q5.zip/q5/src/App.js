import { useState } from 'react';
import './App.css';
// library for paginating results 
import ArrayPagination from '@vlsergey/react-bootstrap-array-pagination';

function App() {

  // state hooks used here for variables
  const [word, setWord] = useState('');
  const [wordList, setWordList] = useState(null);

  // handler for word change
  function handleWordChange(e) {
    setWord(e.target.value);
  }

  // handler for submit button
  function handleSubmit() {
    if (word) {
      fetch(`https://api.datamuse.com/words?sl=${word}`).then((res) => {
        return res.json();
      }).then((data) => {
        setWordList(data);
      });
    } else {
      alert("kindly enter a word !!!!");
    }

  }

  return (
    <div className="App">
      <div className='container p-5'>
        <div className="row">
          <div className="col">
            <div className="mb-3">
              <label htmlFor="word" className="form-label">Enter a word to list rhyming words and press submit!!!</label>
              <input type="text" className="form-control" id="word" value={word} onChange={handleWordChange} />
            </div>
            <div className="col-auto">
              <button type="submit" className="btn btn-primary mb-3" onClick={handleSubmit}>Submit</button>
            </div>
          </div>
          <div className="col">
            <div className="d-grid gap-3">
              {wordList && <ArrayPagination
                defaultSize={5}
                items={wordList}>
                {({ components, pageItems }) => <>
                  {pageItems.map(item => <div className="p-2 bg-light border">{item.word}</div>)}
                  {components}
                </>}
              </ArrayPagination>}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
